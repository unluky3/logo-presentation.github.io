# Kippo Hover Card Effect (@hyperplexed)

A Pen created on CodePen.io. Original URL: [https://codepen.io/lev-lukianov/pen/NWmdPLX](https://codepen.io/lev-lukianov/pen/NWmdPLX).

